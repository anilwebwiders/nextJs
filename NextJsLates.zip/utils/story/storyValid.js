const storyValid = (title, communityId) => {
  if (!title || !communityId )
    return "Please fill Title, Community Categories and Body";
};

export default storyValid;
