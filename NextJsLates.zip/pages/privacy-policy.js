import HeadData from "../component/HeadData";
import Privacy from "../component/Conditions/Privacy";

const PrivaceData = () => {
  return (
    <div>
      <HeadData />
      <Privacy />
    </div>
  );
};

export default PrivaceData;
