import React from "react";

const PreloaderLg = () => {
  return (
    <div className="d-flex justify-content-center align-items-center my-5">
      <div className="loaderLg"></div>
    </div>
  );
};

export default PreloaderLg;
