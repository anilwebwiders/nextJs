import React from "react";

const NormalPreloader = () => {
  return (
    <div className="my-5">
      <div className="loaderLg"></div>
    </div>
  );
};

export default NormalPreloader;
