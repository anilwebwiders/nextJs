export const emailNotificationsStory = {
  story_likes: "Likes",
  story_comments: "Comments",
  story_post: "Successful Post",
  main_story_likes: "Likes",
  main_story_comments: "Comments",
  main_story_post: "Successful Post",
};
export const emailNotificationsArticle = {
  article_likes: "Likes",
  article_comments: "Comments",
  article_post: "Successful Post",
  main_article_likes: "Likes",
  main_article_comments: "Comments",
  main_article_post: "Successful Post",
};

export const emailNotificationsOther = {
  followers: "New Follower",
  subscription: "Category Subscription Alerts",
  following: "Posts by Following Alerts",
  main_followers: "New Follower",
  main_subscription: "Category Subscription Alerts",
  main_following: "Posts by Following Alerts",
};

export const emailNotifications = {
  story_likes: "Likes",
  story_comments: "Comments",
  story_post: "Successful Post",
  article_likes: "Likes",
  article_comments: "Comments",
  article_post: "Successful Post",
  followers: "New Follower",
  subscription: "Category Subscription Alerts",
  following: "Posts by Following Alerts",
  main_story_likes: "Likes",
  main_story_comments: "Comments",
  main_story_post: "Successful Post",
  main_article_likes: "Likes",
  main_article_comments: "Comments",
  main_article_post: "Successful Post",
  main_followers: "New Follower",
  main_subscription: "Category Subscription Alerts",
  main_following: "Posts by Following Alerts",
};


